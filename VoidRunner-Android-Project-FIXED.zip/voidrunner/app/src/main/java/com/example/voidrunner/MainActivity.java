package com.example.voidrunner;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import java.util.*;

public class MainActivity extends Activity{
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024);setContentView(new GameView(this));}
}
class GameView extends View{
 Paint p=new Paint(3); Random r=new Random(); ArrayList<Orb> orbs=new ArrayList<>(); SharedPreferences sp;
 float px,py; int score=0,best=0,lives=3,combo=0; long start,last; boolean running=false,gameOver=false;
 GameView(Context c){super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD));sp=c.getSharedPreferences("save",0);best=sp.getInt("best",0);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 void text(Canvas c,String s,float x,float y,float size,Paint.Align a){p.setTextSize(size);p.setTextAlign(a);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setShadowLayer(8,0,0,Color.CYAN);c.drawText(s,x,y,p);p.clearShadowLayer();}
 protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();c.drawColor(Color.rgb(5,6,11));
  // grid
  p.setColor(Color.rgb(12,20,30));p.setStrokeWidth(1);for(int x=0;x<w;x+=48)c.drawLine(x,0,x,h,p);for(int y=0;y<h;y+=48)c.drawLine(0,y,w,y,p);
  if(!running&&!gameOver){text(c,"VOID RUNNER",w/2,150,44,Paint.Align.CENTER);text(c,"ECHO HUNT",w/2,195,20,Paint.Align.CENTER);text(c,"Лови светящиеся ядра. Не дай им исчезнуть.",w/2,260,16,Paint.Align.CENTER);button(c,w/2,h/2+40,260,74,"НАЧАТЬ ЗАБЕГ");text(c,"РЕКОРД  "+best,w/2,h-80,18,Paint.Align.CENTER);return;}
  text(c,"SCORE  "+score,24,42,22,Paint.Align.LEFT);text(c,"BEST  "+best,w-24,42,18,Paint.Align.RIGHT);text(c,"❤ "+lives,w/2,42,20,Paint.Align.CENTER);text(c,"COMBO x"+Math.max(1,combo),w/2,74,16,Paint.Align.CENTER);
  for(Orb o:orbs)o.draw(c); if(gameOver){p.setColor(0xCC05060B);c.drawRect(0,0,w,h,p);text(c,"ЗАБЕГ ОКОНЧЕН",w/2,h/2-70,34,Paint.Align.CENTER);text(c,"Счёт: "+score,w/2,h/2-20,22,Paint.Align.CENTER);button(c,w/2,h/2+70,240,68,"ЕЩЁ РАЗ");}
  invalidate();
 }
 void button(Canvas c,float x,float y,float bw,float bh,String s){p.setColor(0xFF102532);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x-bw/2,y-bh/2,x+bw/2,y+bh/2,20,20,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.CYAN);c.drawRoundRect(x-bw/2,y-bh/2,x+bw/2,y+bh/2,20,20,p);p.setStyle(Paint.Style.FILL);text(c,s,x,y+8,18,Paint.Align.CENTER);}
 public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=1)return true;float x=e.getX(),y=e.getY();int w=getWidth(),h=getHeight();
  if(!running){if(!gameOver&&y>h/2&&y<h/2+110){startGame();}else if(gameOver&&y>h/2+30&&y<h/2+130)startGame();return true;}
  for(int i=orbs.size()-1;i>=0;i--){Orb o=orbs.get(i);if(Math.hypot(x-o.x,y-o.y)<o.rad+25){score+=10+combo*2;combo++;orbs.remove(i);return true;}}
  combo=0;return true;}
 void startGame(){running=true;gameOver=false;score=0;lives=3;combo=0;orbs.clear();start=last=System.currentTimeMillis();for(int i=0;i<4;i++)spawn();}
 void spawn(){int w=getWidth(),h=getHeight();orbs.add(new Orb(50+r.nextInt(Math.max(1,w-100)),110+r.nextInt(Math.max(1,h-180)),18+r.nextInt(10),1.8f+r.nextFloat()*2));}
 class Orb{float x,y,rad,spd;long born=System.currentTimeMillis();Orb(float a,float b,float c,float d){x=a;y=b;rad=c;spd=d;}void draw(Canvas c){float life=(System.currentTimeMillis()-born)/1000f;float pulse=(float)Math.sin(life*6)*3; p.setShader(new RadialGradient(x,y,rad+10,Color.CYAN,0x0000E5FF,Shader.TileMode.CLAMP));c.drawCircle(x,y,rad+10+pulse,p);p.setShader(null);p.setColor(Color.WHITE);c.drawCircle(x,y,rad/3,p);}}
 public void invalidate(){long now=System.currentTimeMillis();if(running&&!gameOver){if(now-last>800){spawn();last=now;}for(int i=orbs.size()-1;i>=0;i--){Orb o=orbs.get(i);if(now-o.born>3200){orbs.remove(i);lives--;combo=0;if(lives<=0){running=false;gameOver=true;if(score>best){best=score;sp.edit().putInt("best",best).apply();}break;}}}}super.invalidate();}
}
