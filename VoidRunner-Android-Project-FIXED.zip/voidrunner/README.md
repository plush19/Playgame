# VoidRunner

Android game project. Build locally with Gradle 8.11.1 + JDK 17, or use the included GitHub Actions workflow.

## Phone-only build
1. Create a GitHub repository.
2. Upload the contents of this folder.
3. Open Actions -> Build APK -> Run workflow.
4. Download the `VoidRunner-debug-apk` artifact.
